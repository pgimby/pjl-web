

//*******************************************************************************************
//   GLOBALS
//*******************************************************************************************

var mainxmlpath = "../data/pjl.xml";
var zipoutputfilename = "PJL-lab-docs.zip";






//*******************************************************************************************
//   PAGE INITIALIZATION
//*******************************************************************************************



function initPage() {
	loadXML();
}









//*******************************************************************************************
//   GENERAL FUNCTIONS
//*******************************************************************************************



function loadXML() {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
            docXML = this.responseXML;
            populateRecordList(docXML);
            populateFilters(docXML);
    	}
  	};
  	xhttp.open("GET", mainxmlpath, true);
  	xhttp.send();
} 



function getCurrentRecords() {  //returns currently displayed lab records as array of jquery objects
	var list = [];
	var lablist = $(".lab-record-flex");
	for (var i = lablist.length - 1; i >= 0; i--) {
		if($(lablist[i]).css("display") != "none") {
			list.push($(lablist[i]));
		}
	}
	return list;
}



function getAllRecords() {  //returns all lab records as array of jquery objects
	var list = [];
	var lablist = $(".lab-record-flex");
	for (var i = lablist.length - 1; i >= 0; i--) {
		list.push($(lablist[i]));
	}
	return list;
}



function countNumRecords() {
	var currentrecords = getCurrentRecords();
	return currentrecords.length;
}



function getCurrentFilter() {
	var selects = $("select");
	var filter = {};
	for (var i = selects.length - 1; i >= 0; i--) {
		if (selects[i].value) {
			filter[$(selects[i]).parent().attr("id")] = $(selects[i]).val();
		} else {
			filter[$(selects[i]).parent().attr("id")] = [];
		}
	}
	return filter;
}



function getLabId(lab) {
	return lab.getAttribute("LABID");
}



function mayISeeYourSillyWalk() {
	var itsnotparticularlysillyisit = "The right leg isn't silly at all and the left leg merely does a forward aerial half turn every alternate step.";
	$(".search-icon").attr("src","../img/silly-walk.png");
	$(".search-icon").css({height: "45px", width: "35px", top: "-49px", right: "-35px"})
	$("#search-bar").attr("placeholder", itsnotparticularlysillyisit);
	$("#search-bar").css("font-size", "11px");
	$("#search-bar").val("");
}



function getLabTopicsList(lab) {
	var list = [];
	var topics = lab.getElementsByTagName("topic");
	for (var i = topics.length - 1; i >= 0; i--) {
		list.push(topics[i].childNodes[0].nodeValue);
	}
	return list;
}



function getLabDisciplinesList(lab) {
	var list = [];
	var disciplines = lab.getElementsByTagName("discipline");
	for (var i = disciplines.length - 1; i >= 0; i--) {
		list.push(disciplines[i].childNodes[0].nodeValue);
	}
	return list;
}



function getLabEquipmentList(lab) {
	var list = [];
	var equipment = lab.getElementsByTagName("item");
	for (var i = equipment.length - 1; i >= 0; i--) {
		list.push(equipment[i].getAttribute("name"));
	}
	return list;
}



function getCourseList(lab) {
	var list = [];
	var courses = lab.getElementsByTagName("course");
	for (var i = courses.length - 1; i >= 0; i--) {
		list.push(courses[i].childNodes[0].nodeValue);
	}
	return list;
}



function getVersionList(lab) {
	var versionlist = [];
	var list = lab.getElementsByTagName("version");
	for (var i = list.length - 1; i >= 0; i--) {
		versionlist.push({path: list[i].getElementsByTagName("path")[0].childNodes[0].nodeValue, 
						  semester: list[i].getElementsByTagName("semester")[0].childNodes[0].nodeValue, 
						  year: list[i].getElementsByTagName("year")[0].childNodes[0].nodeValue});
	}
	return versionlist;
}



function getValidFilterOptions(docXML, type) {
	var nodelist = docXML.getElementsByTagName(type);
    var valueslist = [];
    for (var i = 0; i < nodelist.length; i ++) {
	    var value = nodelist[i].childNodes[0].nodeValue;
	    valueslist.push(value);
    }
    return Array.from(new Set(valueslist));
}



function getCurrentRecordPaths() {
	var paths = [];
	var records = getCurrentRecords();
	for (var i = records.length - 1; i >= 0; i--) {
		paths.push(records[i].find(".version-path").attr("href"));
	}
	return paths;
}











//*******************************************************************************************
//   SEARCH-RELATED FUNCTIONS (USING SORENSEN-DICE SIMILARITY)
//*******************************************************************************************



function generateSearchResults(query) {
	var minsimilarity = 0.4;
	var querybigrams = makeBigramList(query);
	var lablist = getAllRecords();
	for (var i = lablist.length - 1; i >= 0; i--) {
		lablist[i].css("display", "-webkit-flex");
		lablist[i].css("display", "flex");
		var similarity = compareQueryWithLabRecord(querybigrams, lablist[i]);
		if (similarity < minsimilarity) {
			lablist[i].css("display", "none");
		}
	}
}



function compareQueryWithLabRecord(querybigrams, lab) {
	var courses = lab.find(".courses").text().split(", ");
	var disciplines = lab.find(".lab-data-disciplines").text().slice(13,).split(", ");
	var topics = lab.find(".lab-data-topics").text().slice(8,).split(", ");
	courses = courses.map(function(d) {
		return makeBigramList(d);
	});
	disciplines = disciplines.map(function(d) {
		return makeBigramList(d);
	});
	topics = topics.map(function(d) {
		return makeBigramList(d);
	});
	var semester = [makeBigramList(lab.find(".version-semester").text())];
	var labtitle = [makeBigramList(lab.find(".lab-title").text())];
	var totest = disciplines.concat(courses, semester, labtitle, topics);
	var max = 0.0;
	for (var i = totest.length - 1; i >= 0; i--) {
		var result = sorensenDiceCoef(querybigrams, totest[i]);
		if (result > max) {
			max = result
		}
	}
	return max;
}



function sorensenDiceCoef(bigrams1, bigrams2) {
	var count = 0;
	$.each(bigrams1, function(i, d) {
		if (bigrams2.includes(d)) {
			count++;
		}
	});
	return 2*count / (bigrams1.length + bigrams2.length);
}







//*******************************************************************************************
//   ZIP-RELATED FUNCTIONS
//*******************************************************************************************



function makePromisesBeginZip() {
	var zip = new JSZip();
	var files = ["../data/testfiles/1.txt","../data/testfiles/2.dat","../data/testfiles/3.js","../data/testfiles/4.jpg"];//getCurrentRecordPaths();
	var promises = []
	for (var i = files.length - 1; i >= 0; i--) {
		var downloadingfile = fileDownloadPromise();
		downloadingfile.done(function(filename, blob) {
			zip.file(filename, blob);
		});
		promises.push(downloadingfile);
		beginDownload(files[i], downloadingfile);
	}
	$.when.apply(this, promises).done(function() {
		zip.generateAsync({type:"blob"}).then(function (blob) {
		saveAs(blob, zipoutputfilename);
	}, function (err) {
          console.log(err); //this should never be thrown as I checked for browser compat. already in canZip()
          					//but for completeness' sake we could write a modal dialog to throw up here.
      });
	return false;
	});
}


function fileDownloadPromise() {
	return new $.Deferred();
}


function beginDownload(filepath, promise) {
	var xhttp = new XMLHttpRequest();
	xhttp.responseType = "blob";
	xhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
            blob = this.response;
            var filename = filepath.split("/");
            filename = filename[filename.length-1];
            promise.resolve(filename, blob);
            console.log("File " + filename + " successfully loaded");
    	} else {
    		console.log("Error on XHTTP Request - Error Code: " + String(this.status));
    	}
  	};
  	xhttp.open("GET", filepath, true);
  	xhttp.send();
}



function canZip() {
	var bool = false;
	if (countNumRecords() > 0 && JSZip.support.blob) {
		bool = true
	}
	return bool;
}







//*******************************************************************************************
//   DOM ELEMENT CREATION FUNCTIONS
//*******************************************************************************************



function populateRecordList(docXML) {
	var labs = docXML.getElementsByTagName("lab");
	for (var i = labs.length - 1; i >= 0; i--) {
		createRecordSnapshots(labs[i]);
	}
	displayNumResults(countNumRecords());
}



function populateFilters(docXML) {
	var types = ["course", "year", "semester", "discipline"];
	for (var i = types.length - 1; i >= 0; i--) {
		var validlist = getValidFilterOptions(docXML, types[i]);
		for (var j = validlist.length - 1; j >= 0; j--) {
			d3.select("#" + types[i] + "-select")
			  .append("option")
			  .attr("value", validlist[j])
			  .html(validlist[j]);
		}
	}
}



function createRecordSnapshots(lab) {
	var versionlist = getVersionList(lab);
	for (var i = versionlist.length - 1; i >= 0; i--) {
		var detailsbox = d3.select("#lab-list-box").append("div").classed("lab-record-flex", true);

		var snapshot = detailsbox.append("div").classed("snapshot-flex", true);
		var download = snapshot.append("a").classed("version-path", true).html("Download").attr("href", versionlist[i].path);
		var courses = snapshot.append("p").classed("courses", true).html(getCourseList(lab).join(", "));
		var date = snapshot.append("p").classed("version-semester", true).html(versionlist[i].semester + " " + versionlist[i].year);
		var labtitle = snapshot.append("p").classed("lab-title", true).html(lab.getElementsByTagName("name")[0].childNodes[0].nodeValue);
		var dropiconflex = snapshot.append("div").classed("lab-details-drop-icon-flex", true);
		var dropicon = dropiconflex.append("img").classed("lab-details-drop-icon", true).attr("src", "../img/dropdown-arrow.png");

		var extendedlabdata = detailsbox.append("div").classed("extended-lab-data-flex", true);
		var labid = extendedlabdata.append("p").classed("lab-data-id", true).html("Lab ID: " + getLabId(lab));
		var labtopics = extendedlabdata.append("p").classed("lab-data-topics", true).html("Topics: " + getLabTopicsList(lab).join(", "));
		var labdisciplines = extendedlabdata.append("p").classed("lab-data-disciplines", true).html("Disciplines: " + getLabDisciplinesList(lab).join(", "));
		var labequipment = extendedlabdata.append("p").classed("lab-data-equipment", true).html("Equipment: " + getLabEquipmentList(lab).join(", "));
		var labdocs = extendedlabdata.append("a").classed("lab-data-docs", true)
									 .attr("href", lab.getElementsByTagName("doc")[0].childNodes[0].nodeValue)
									 .html(lab.getElementsByTagName("doc")[0].getAttribute("type"));
	}
}









//*******************************************************************************************
//   EVENT LISTENERS
//*******************************************************************************************



$(document).on("click", ".lab-details-drop-icon-flex", function(e) {
	var extendeddataflex = $(e.target).parent().siblings(".extended-lab-data-flex");
	extendeddataflex.slideToggle("fast");
});



$(document).on("click", "#clear-filters-button", function(e) {
	var selects = $("select");
	for (var i = selects.length - 1; i >= 0; i--) {
		$(selects[i]).val([]);
	}
	filterResults(getCurrentFilter());
	displayNumResults(countNumRecords());
});



$(document).on("click", "select", function(e) {
	filterResults(getCurrentFilter());
	displayNumResults(countNumRecords());
});



$(document).on("mousedown", "option", function(e) {
    e.preventDefault();
    $(this).prop('selected', !$(this).prop('selected'));
    return false;
});



$(document).on("click", ".search-icon", function(e) {
	var query = $("#search-bar").val();
	if (query == "silly walk") {
		mayISeeYourSillyWalk();
		return;
	}
	$('html, body').animate({scrollTop: ($('#lab-list-box').offset().top)}, 500);
	generateSearchResults(query);
	displayNumResults(countNumRecords());
	 $("#search-bar").val("");
});



$(document).on("keypress", "#search-bar", function(e) {
	var key = e.which;
	if (key == 13) {
	 	$(".search-icon").click();
	 	return false;
	}
});



$(document).on("click", "#zip-icon", function(e) {
	makePromisesBeginZip();
})







//*******************************************************************************************
//   CONVENIENCE FUNCTIONS
//*******************************************************************************************



function doArraysOverlap(array1, array2) {
	return array1.some(x => array2.includes(x));
}



function makeBigramList(string) {
	list = [];
	var string = string.toLowerCase();
	for (var i = 0; i <= string.length - 2; i++) {
		list.push(string[i] + string[i+1]);
	}
	return Array.from(new Set(list));
}



function arithmeticMean(list) {
	return list.reduce((a, b) => a + b, 0) / list.length;
}










//*******************************************************************************************
//   DOM MODIFIER FUNCTIONS
//*******************************************************************************************



function filterResults(filter) {
	var lablist = $(".lab-record-flex");
	var numrecords = lablist.length;
	for (var i = lablist.length - 1; i >= 0; i--) {
		var lab = $(lablist[i]);
		var courses = lab.find(".courses").text().split(", ");
		var disciplines = lab.find(".lab-data-disciplines").text().slice(13,).split(", ");

		if (filter["year-filter"].includes(lab.find(".version-semester").text().slice(-4))       || filter["year-filter"].length == 0) {
			lab.css("display", "-webkit-flex");
			lab.css("display", "flex");
		} else {
			lab.css("display", "none");
			numrecords--;
			continue;
		}
		if (doArraysOverlap(courses, filter["course-filter"])                                    || filter["course-filter"].length == 0) {
			lab.css("display", "-webkit-flex");
			lab.css("display", "flex");
		} else {
			lab.css("display", "none");
			numrecords--;
			continue;
		}
		if (filter["semester-filter"].includes(lab.find(".version-semester").text().slice(0,-5)) || filter["semester-filter"].length == 0) {
			lab.css("display", "-webkit-flex");
			lab.css("display", "flex");
		} else {
			lab.css("display", "none");
			numrecords--;
			continue;
		}
		if (doArraysOverlap(disciplines, filter["discipline-filter"])                            || filter["discipline-filter"].length == 0) {
			lab.css("display", "-webkit-flex");
			lab.css("display", "flex");
		} else {
			lab.css("display", "none");
			numrecords--;
			continue;
		}
	}
}


 
function displayNumResults(numresults) {
	$("#num-results").text(numresults);
	updateZipStatus();
}



function updateZipStatus() {
	var canzip = canZip()
	if (canzip) {
		$("#zip-icon").css("display", "inline-block");
	} else {
		$("#zip-icon").css("display", "none");
	}
}








